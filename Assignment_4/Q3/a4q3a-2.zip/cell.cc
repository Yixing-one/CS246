#include "subject.h"
#include "observer.h"
#include "cell.h"

Cell::Cell() {
    isOn = false;
} 

Cell::~Cell() {
    observers.erase(observers.begin(), observers.end());
}

bool Cell::getState() const { 
    return isOn; 
}

int Cell::getRow() const { 
    return r; 
}
int Cell::getCol() const {
    return c; 
}

void Cell::setOn() {
    isOn = true;
}

void Cell::toggle() {
    if(isOn) {
        isOn = false;
    } else {
        isOn = true;
    }
}

void Cell::setCoords(int r, int c) {
    this->r = r; this->c = c; 
}

void Cell::notify(Cell & whoNotified) {
    toggle();
}

void Cell::notifyObservers(SubscriptionType t) {
        for(auto n : observers){
		 n->notify(*this);
	    }
}

SubscriptionType Cell::subType() const {
  return SubscriptionType::SwitchOnly;
}

std::string Cell::getName() const {
return " ";
}
