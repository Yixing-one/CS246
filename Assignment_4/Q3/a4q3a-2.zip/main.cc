#include <iostream>
#include <string>
#include "grid.h"

using namespace std;

int main() {
  cin.exceptions(ios::eofbit|ios::failbit);
  string cmd, aux;
  Grid g;

  while (true) {
   try{
    cin >> cmd;
   } 
   catch(ios::failure &) {
       if (cin.eof()) { break;}
       cin.clear();
       cin.ignore();
    }
    if (cmd == "new") {
      int n;
       try{
           cin >> n;
         } 
       catch(ios::failure &) {
           if (cin.eof()) { break;}
           cin.clear();
           cin.ignore();
        }
      g.init(n);
    }
    else if (cmd == "init") {
        int i, k;
        while (cin >> i >> k)  {
            if(i==-1 && k==-1){
                break;
            }
            g.turnOn(i,k);
        }
      cout << g;
    }
    else if ( cmd == "neighbours" ) {
      g.printCells();
    }
    else if (cmd == "game") {
        int i;
        try{
           cin >> i;
         } 
       catch(ios::failure &) {
           if (cin.eof()) { break;}
           cin.clear();
           cin.ignore();
        }
        if (i == 1) {
            cout << i << " move left" << endl;
        } else {
            cout << i << " moves left" << endl;
        }
        int move = i;
        while (move > 0) {
            if (g.isWon()) {
                cout << "Won" << endl;
                return 0;
            }
            string s;
            cin >> s;
            if (cin.eof()) {
                return 0; 
            }
            int i, k;
            if (s == "switch") {
                cin >> i >> k;
                g.toggle(i,k);
                cout << g;
                move--;
                if (move == 1) {
                     cout << move << " move left" << endl;
                    } else {
                      cout << move << " moves left" << endl;
		    }
		if (g.isWon()) {
                     cout << "Won" << endl;
                     return 0;
                }
                    
            }
        }
        if (!g.isWon()) { 
            cout << "Lost" << endl;
	    return 0;
        }
    } else if (cmd == "switch") {
      int i, k;
      cin >> i >> k;
      g.toggle(i,k);  
      cout << g;
    }
  }
}
